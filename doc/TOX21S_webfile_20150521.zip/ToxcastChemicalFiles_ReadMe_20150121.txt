Revised 20150521

A error was detected in the originally posted TOX21S_v4b_8599_23Oct2014.xlsx file that would give incorrect
mapping of Chemical names and CASRN to RID, GSID, CID and structure information (e.g., SMILES). 

The current TOX21S files contain additional chemicals currently undergoing testing, and is derived from the
most recently updated DSSTox_v2 database in which no "representative" structures are allowed which would 
violate the 1:1 GSID to CID-structure mapping rule. The SDF is generated in v3000 format (supported by
ChemAxon JChem) in order to capture stereochemical distinctions and may not be compatible with some user 
applications. The file can be converted to the older v2000 format or the SMILES provided in the TOX21S 
Excel file that are v2000 compatible can be used to circumvent this issue.

ToxCast Phase2 (New Pipeline) Data Release 20141112

DSSTox Chemical & ID Map Files



Chemical File 1. TOX21S_v4b_8599_23Oct2014.xlsx

Updated DSSTox TOX21S file containing chemical details for 8599 unique substances (GSIDs),
and the following updated DSSTox Standard Chemical Fields (original field names in parentheses
have been shortened or modified to enhance their utility): 

DSSTox_RID  
DSSTox_GSID 		(DSSTox_Generic_SID)
DSSTox_CID
TS_ChemName 		(TestSubstance_ChemicalName)
TS_ChemName_Synonyms	(new standard field)
TS_CASRN		(TestSubstance_CASRN)
TS_Description		(TestSubstance_Description)
ChemNote		(ChemicalNote)
STRUCTURE_Shown
STRUCTURE_Formula
STRUCTURE_MW 		(STRUCTURE_MolecularWeight)
STRUCTURE_ChemType 	(STRUCTURE_ChemicalType
STRUCTURE_DefinedOrganicForm 	(STRUCTURE_TestedForm_DefinedOrganic)	
STRUCTURE_IUPAC		(STRUCTURE_ChemicalName_IUPAC)
STRUCTURE_SMILES
STRUCTURE_SMILES_Desalt	(STRUCTURE_Parent_SMILES)
STRUCTURE_InChIS_v0	(STRUCTURE_InChI)
STRUCTURE_InChIKey_v0	(STRUCTURE_InChIKey)
Substance_modify_yyyymmdd

For definitions and details of original DSSTox Standard Chemical Fields, see:
http://www.epa.gov/ncct/dsstox/StandardChemFieldDefTable.html


TOX21S_v4b contains all EPA ToxCast chemical GSIDs for this data release, in addition to all
chemicals contained in the larger Tox21 library.

Map of DSSTox Chemical Fields to chemical identifiers in ToxCast Data files:

code 	e.g. C100016		(Unformatted version of DSSTox_CASRN)
chid	e.g. 20961		(DSSTox_GSID)
casn	e.g. 100-01-6		(DSSTox_CASRN)
chnm	e.g. 4-Nitroaniline	(DSSTox_ChemName)



Chemical File 2:  TOX21S_v4b_CID_structures.sdf

Updated DSSTox TOX21S sdf (structures) file containing structures (mol blocks) for the unique list of
DSSTox_CIDs contained in File 1, indexed by DSSTox_CID.  
* Note that this CID file contains fewer entries than the main Tox21S file (File 1) due to the presence of 
representative structures included for some CAS substances that are mixtures, creating duplicates within the
main file.  



Chemical File 3:  TOX21IDs_v4b_23Oct2014_QCdetails.xlsx

Tox21ID mapping file containing Tox21 stock solution-level codes (Tox21IDs) linked to generic substance 
ID (DSSTox_GSID), PubChem substance ID (PUBCHEM_SID), and summarized analytical QC results from the Tox21 
testing program (QC_Grade; QC_Grade_Description).

Tox21ID - sample 
DSSTox_GSID
QC_Grade
QC_Grade_Description
PUBCHEM_SID

For the purpose of this data release, a summary "QC_Grade" is listed, with further details provided in
"QC_Grade_Description" as indicated below:

QC_Grade	QC_Grade_Description
Pass		Purity>90% and MW confirmed
		Purity>50% and MW confirmed
		Purity >75% and MW confirmed
Pass MW		MW confirmed, no purity info
Caution		Low purity or concentration
		No sample detected
Not determined	Analysis in progress
		Sample withdrawn
		Unsuitable for analysis

Chemical information for Tox21ID samples can be retrieved from the other Chemical Files using the DSSTox_GSID (chid)
and DSSTox_CID (for structures).  PUBCHEM_SID column can be used to retrieve all Tox21 data currently deposited
by Tox21's NIH/NCGC partner in PubChem. Note that the EPA ToxCast data pipeline processed results for these 
chemical samples may differ from those in PubChem due to different curve-fitting and hit-call algorithms used.  
		